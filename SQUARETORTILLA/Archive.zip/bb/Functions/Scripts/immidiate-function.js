﻿
console.log("//immidiate function");

//sample a
(function(){
	console.log( "a" );
})();

//sample b
(function(){
	console.log( "b" );
}());
